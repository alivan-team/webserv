# Webserv Evaluation Showcase

This package is designed to be extracted into the **root of the webserv repository**. It only adds new paths:

- `site/evaluation_www/`
- `site/evaluation_www_alt/`
- `config/evaluation_showcase.conf`

## Run

```bash
make
./webserv config/evaluation_showcase.conf
```

Then open:

- `http://localhost:8080/` — main interactive evaluation console
- `http://localhost:8081/` — second listening-port demonstration

## Browser-driven demonstrations

The main page lets an evaluator demonstrate:

- static GET and configured index files
- route-specific roots and allowed methods
- autoindex generation
- 301 redirect
- multipart file upload with POST (201)
- listing uploaded files using autoindex
- DELETE on uploaded files (204)
- Python CGI GET and POST
- CGI environment/body plumbing
- custom error pages
- 405 Method Not Allowed + `Allow` header
- 413 Payload Too Large
- 501 for an unsupported method
- two listening ports with different content

## CGI interpreter path

The config uses:

```text
cgi_path /usr/bin/python3;
```

If `python3` lives elsewhere on the evaluation machine, change that one line to the absolute interpreter path returned by `which python3`.

## Resetting the upload demo

The dashboard can delete files from `site/evaluation_www/uploads/`. Re-extract this package if you want to restore the seeded `delete-me.txt` and `welcome.txt` files.

## Important implementation note

Your current `handlePost()` builds its successful upload response body from `./site/www/post-result.html`. The dashboard uses `fetch()` and reports the HTTP 201 + `Location` header, so the evaluator stays on the showcase page and does not depend on that response body's appearance.
